<div class="container-fluid">
 <div class="row">
 	<div class="col-md-6 col-md-offset-3 mar-100">
 		<h1>group class schedule</h1>
 	</div>
 </div>
  <div class="col-md-10 col-md-offset-1">
    <iframe class="wodify" src="https://app.wodify.com/Schedule/PublicCalendarListView.aspx?tenant=1908" width="100%" height="800"></iframe>
  </div>
</div>
  <hr>
