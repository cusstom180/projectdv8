<div class="container-fluid">
	<div class="row mar-50 mar-bot-50">
		<div class="col-md-6 col-md-offset-3">
			<h1 class="text-uppercase">welcome community</h1>
			<h3>Our community is unlike any in Rochester. Warm and welcoming to all who walk through its doors, our athletes are quick to give encouragement and support to everyone. Athletes become friends, and friends become family at DV8. We strive to create an environment that makes everyone feel comfortable, and we believe every athlete has the potential to be great! Come in and see us between the Firestone building and Sargent Appliance.
			</h3>
		</div>
	</div>
</div>

<div class="jumbotron text-center work">
  <h1>get started today</h1>
  <p>
  	<a class="btn btn-default btn-lg" href="getting-started.php" role="button">i'm new to crossfit <i class="fa fa-arrow-right hide1" aria-hidden="true"></i></a>
  	<a class="btn btn-default btn-lg" href="class-schedule.php" role="button">not my first rodeo <i class="fa fa-arrow-right hide1" aria-hidden="true"></i></a>
  </p>
</div>