<div class="row footer">
  <div class="col-md-5 col-md-offset-1 mar-50 padding-2">
	  <li>CrossFit Deviate</li>
   	  <li><a href="mailto:crossfitdv8@gmail.com">crossfitdv8@gmail.com</a></li>
   	  <li>528 N. Main street, unit D</li>
   	  <li>Rochester, MI 48307</li>
   	  <li><a href="tel:2482666688"><span>(246) 266-6688</span></a></li>
      <p>Copyright &copy; 2017 &middot; All Rights Reserved &middot; <a href="http://www.crossfitdeviate.com/" >CrossFit Deviate</a></p>
      <a href="https://www.facebook.com/CrossfitDV8/" title="CrossFit DV8 Facebook page" target="_blank"><i class="fa fa-facebook-square fa-2x footer-icon" aria-hidden="true"></i></a>
      <a href="https://www.instagram.com/crossfitdv8/" title="CrossFit DV8 Instragram" target="_blank"><i class="fa fa-instagram fa-2x footer-ico" aria-hidden="true"></i></a>
      <a href="https://twitter.com/CrossFitDV8" title="CrossFit DV8 twitter" target="_blank"><i class="fa fa-twitter-square fa-2x footer-ico" aria-hidden="true"></i></a>
      <div class="container"></div>
    </div>
   <div class="col-md-6">
    <div class="col-md-2 col-md-offset-2 mar-50"><a href="http://rpmtraining.com?utm_source=affiliate&utm_campaign=affiliate&utm_medium=banner&utm_content=crossfit-deviate">
      <img class="img-responsive" src="http://cdn.rpmfitness.com/images/affiliate/rpmfitness-affiliate-03.jpg" width="200" height="167" alt="RPM Training">
    </a></div>
    <div class="col-md-2 col-md-offset-2 mar-50">      <a href="https://journal.crossfit.com" target="_blank" title="CrossFit Journal: The Performance-Based Lifestyle Resource"><img src="https://de45qwmlmgefw.cloudfront.net/badges/black-125x63.png" width="125px" height="63px" alt="CrossFit Journal: The Performance-Based Lifestyle Resource" /></a></div>
   </div>
   
</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="<?php echo base_url('public_html/javascript/jquery-1.11.3.min.js'); ?>"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo base_url('public_html/javascript/site_jquery.js'); ?>"></script>
<script src="<?php echo base_url('public_html/javascript/bootstrap-3.3.7.js'); ?>"></script>
<script src="<?php echo base_url('public_html/javascript/carousel.js'); ?>"></script>

</body>
</html>
