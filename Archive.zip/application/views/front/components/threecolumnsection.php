<div class="container-fluid">
    <div class="row">
        <div id="left-index" class="col-md-4"></div>
        <div id="center-index" class="col-md-4">
       		<i class="fa fa-quote-left fa-pull-left" aria-hidden="true"></i>
            	<h2>The magic is in the movement, the art is in the programming, the science is in the explanation, and the fun is in the community.</h2>
            	<i class="fa fa-quote-right fa-pull-right" aria-hidden="true"></i>
            	<h3 class="fa-pull-right">&#8212; Coach Greg Glassman</h3>
        </div>
        <div id="right-index" class="col-md-4"> </div>
    </div>
</div>