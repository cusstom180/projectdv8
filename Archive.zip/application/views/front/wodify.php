<div class="container-fluid">
  	<div class="col-md-10 col-md-offset-1">
  		<?php foreach ($wodify as $iframe) { ?>
  		<iframe class="wodify" src="<?php echo $iframe['link']; ?>"></iframe>
  		<?php } ?>
 	</div>
</div>
  