<?php

$this->load->view('front/components/getstarted');

