<?php 
$this->load->view('front/components/carousel1'); 
$this->load->view('front/components/jumbotron');
$this->load->view('front/components/threecolumnsection');
$this->load->view('front/components/testy');
 ?>
