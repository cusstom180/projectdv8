<?php
$this->load->view('admin/components/header');
$this->load->view($subview);

$this->load->view('admin/components/footer'); ?>
