

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="<?php echo base_url('public_html/javascript/jquery-1.11.3.min.js'); ?>"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="<?php echo base_url('public_html/javascript/site_jquery.js'); ?>"></script>
<script src="<?php echo base_url('public_html/javascript/bootstrap-3.3.7.js'); ?>"></script>
<script src="<?php echo base_url('public_html/javascript/carousel.js'); ?>"></script>

</body>
</html>
