<?php
echo 'success ';
echo $login;