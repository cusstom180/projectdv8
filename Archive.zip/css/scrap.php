<?php

<?php echo link_tag('public_html/bootstrap/stylesheets/styles.css', 'stylesheet', 'text/css', false);?>
<?php echo link_tag('public_html/bootstrap/stylesheets/font-awesome.css', 'stylesheet', 'text/css', false);?>