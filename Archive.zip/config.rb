
css_dir = "public_html/bootstrap/stylesheets" # by Compass.app 
sass_dir = "public_html/bootstrap/sass" # by Compass.app 
images_dir = "public_html/images" # by Compass.app 
output_style = :nested # by Compass.app 
relative_assets = false # by Compass.app 
line_comments = true # by Compass.app 
sass_options = {:debug_info=>true} # by Compass.app 
sourcemap = false # by Compass.app 